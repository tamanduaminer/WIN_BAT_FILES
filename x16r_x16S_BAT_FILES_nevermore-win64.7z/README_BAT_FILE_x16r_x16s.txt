This is a collection of BAT files I'm using to mine under Windows 10 for various miners and algos.

Each folder contains some of the coins/tokens I've mined on various pools in regards to their respective algos.

They all are run by an "AUTO BAT" file, which restarts theam after X minutes. This variable can be changed depending on your particular needs. In case the miner gets stuck, after X amount of time, this will force the miner to quit, and then restart.
